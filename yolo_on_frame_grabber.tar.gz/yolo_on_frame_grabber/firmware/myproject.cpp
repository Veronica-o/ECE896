#include <iostream>

#include "myproject.h"
#include "parameters.h"

void myproject(
    hls::stream<input_t> &input_1,
    hls::stream<result_t> &layer29_out
) {

    // hls-fpga-machine-learning insert IO
    #pragma HLS INTERFACE axis port=input_1,layer29_out 
    #pragma HLS DATAFLOW 

#ifndef __SYNTHESIS__
    static bool loaded_weights = false;
    if (!loaded_weights) {
        // hls-fpga-machine-learning insert load weights
        nnet::load_weights_from_txt<weight2_t, 144>(w2, "w2.txt");
        nnet::load_weights_from_txt<bias2_t, 16>(b2, "b2.txt");
        nnet::load_weights_from_txt<batch_normalization_scale_t, 16>(s6, "s6.txt");
        nnet::load_weights_from_txt<batch_normalization_bias_t, 16>(b6, "b6.txt");
        nnet::load_weights_from_txt<weight7_t, 2304>(w7, "w7.txt");
        nnet::load_weights_from_txt<bias7_t, 16>(b7, "b7.txt");
        nnet::load_weights_from_txt<batch_normalization_1_scale_t, 16>(s11, "s11.txt");
        nnet::load_weights_from_txt<batch_normalization_1_bias_t, 16>(b11, "b11.txt");
        nnet::load_weights_from_txt<weight12_t, 2304>(w12, "w12.txt");
        nnet::load_weights_from_txt<bias12_t, 16>(b12, "b12.txt");
        nnet::load_weights_from_txt<batch_normalization_2_scale_t, 16>(s16, "s16.txt");
        nnet::load_weights_from_txt<batch_normalization_2_bias_t, 16>(b16, "b16.txt");
        nnet::load_weights_from_txt<weight17_t, 2304>(w17, "w17.txt");
        nnet::load_weights_from_txt<bias17_t, 16>(b17, "b17.txt");
        nnet::load_weights_from_txt<batch_normalization_3_scale_t, 16>(s21, "s21.txt");
        nnet::load_weights_from_txt<batch_normalization_3_bias_t, 16>(b21, "b21.txt");
        nnet::load_weights_from_txt<weight22_t, 144>(w22, "w22.txt");
        nnet::load_weights_from_txt<bias22_t, 1>(b22, "b22.txt");
        nnet::load_weights_from_txt<weight24_t, 576>(w24, "w24.txt");
        nnet::load_weights_from_txt<bias24_t, 4>(b24, "b24.txt");
        nnet::load_weights_from_txt<weight27_t, 1440>(w27, "w27.txt");
        nnet::load_weights_from_txt<bias27_t, 10>(b27, "b27.txt");
        loaded_weights = true;
    }
#endif

    // ****************************************
    // NETWORK INSTANTIATION
    // ****************************************

    // hls-fpga-machine-learning insert layers

    hls::stream<layer31_t> layer31_out("layer31_out");
    #pragma HLS STREAM variable=layer31_out depth=16900
    nnet::zeropad2d_cl<input_t, layer31_t, config31>(input_1, layer31_out); // zp2d_q_conv2d

    hls::stream<layer2_t> layer2_out("layer2_out");
    #pragma HLS STREAM variable=layer2_out depth=16384
    nnet::conv_2d_cl<layer31_t, layer2_t, config2>(layer31_out, layer2_out, w2, b2); // q_conv2d

    hls::stream<layer4_t> layer4_out("layer4_out");
    #pragma HLS STREAM variable=layer4_out depth=16384
    nnet::relu<layer2_t, layer4_t, relu_config4>(layer2_out, layer4_out); // q_activation

    hls::stream<layer5_t> layer5_out("layer5_out");
    #pragma HLS STREAM variable=layer5_out depth=4096
    nnet::pooling2d_cl<layer4_t, layer5_t, config5>(layer4_out, layer5_out); // max_pooling2d

    hls::stream<layer6_t> layer6_out("layer6_out");
    #pragma HLS STREAM variable=layer6_out depth=4096
    nnet::normalize<layer5_t, layer6_t, config6>(layer5_out, layer6_out, s6, b6); // batch_normalization

    hls::stream<layer32_t> layer32_out("layer32_out");
    #pragma HLS STREAM variable=layer32_out depth=4356
    nnet::zeropad2d_cl<layer6_t, layer32_t, config32>(layer6_out, layer32_out); // zp2d_q_conv2d_1

    hls::stream<layer7_t> layer7_out("layer7_out");
    #pragma HLS STREAM variable=layer7_out depth=4096
    nnet::conv_2d_cl<layer32_t, layer7_t, config7>(layer32_out, layer7_out, w7, b7); // q_conv2d_1

    hls::stream<layer9_t> layer9_out("layer9_out");
    #pragma HLS STREAM variable=layer9_out depth=4096
    nnet::relu<layer7_t, layer9_t, relu_config9>(layer7_out, layer9_out); // q_activation_1

    hls::stream<layer10_t> layer10_out("layer10_out");
    #pragma HLS STREAM variable=layer10_out depth=1024
    nnet::pooling2d_cl<layer9_t, layer10_t, config10>(layer9_out, layer10_out); // max_pooling2d_1

    hls::stream<layer11_t> layer11_out("layer11_out");
    #pragma HLS STREAM variable=layer11_out depth=1024
    nnet::normalize<layer10_t, layer11_t, config11>(layer10_out, layer11_out, s11, b11); // batch_normalization_1

    hls::stream<layer33_t> layer33_out("layer33_out");
    #pragma HLS STREAM variable=layer33_out depth=1156
    nnet::zeropad2d_cl<layer11_t, layer33_t, config33>(layer11_out, layer33_out); // zp2d_q_conv2d_2

    hls::stream<layer12_t> layer12_out("layer12_out");
    #pragma HLS STREAM variable=layer12_out depth=1024
    nnet::conv_2d_cl<layer33_t, layer12_t, config12>(layer33_out, layer12_out, w12, b12); // q_conv2d_2

    hls::stream<layer14_t> layer14_out("layer14_out");
    #pragma HLS STREAM variable=layer14_out depth=1024
    nnet::relu<layer12_t, layer14_t, relu_config14>(layer12_out, layer14_out); // q_activation_2

    hls::stream<layer15_t> layer15_out("layer15_out");
    #pragma HLS STREAM variable=layer15_out depth=256
    nnet::pooling2d_cl<layer14_t, layer15_t, config15>(layer14_out, layer15_out); // max_pooling2d_2

    hls::stream<layer16_t> layer16_out("layer16_out");
    #pragma HLS STREAM variable=layer16_out depth=256
    nnet::normalize<layer15_t, layer16_t, config16>(layer15_out, layer16_out, s16, b16); // batch_normalization_2

    hls::stream<layer34_t> layer34_out("layer34_out");
    #pragma HLS STREAM variable=layer34_out depth=324
    nnet::zeropad2d_cl<layer16_t, layer34_t, config34>(layer16_out, layer34_out); // zp2d_q_conv2d_3

    hls::stream<layer17_t> layer17_out("layer17_out");
    #pragma HLS STREAM variable=layer17_out depth=256
    nnet::conv_2d_cl<layer34_t, layer17_t, config17>(layer34_out, layer17_out, w17, b17); // q_conv2d_3

    hls::stream<layer19_t> layer19_out("layer19_out");
    #pragma HLS STREAM variable=layer19_out depth=256
    nnet::relu<layer17_t, layer19_t, relu_config19>(layer17_out, layer19_out); // q_activation_3

    hls::stream<layer20_t> layer20_out("layer20_out");
    #pragma HLS STREAM variable=layer20_out depth=64
    nnet::pooling2d_cl<layer19_t, layer20_t, config20>(layer19_out, layer20_out); // max_pooling2d_3

    hls::stream<layer21_t> layer21_out("layer21_out");
    #pragma HLS STREAM variable=layer21_out depth=64
    nnet::normalize<layer20_t, layer21_t, config21>(layer20_out, layer21_out, s21, b21); // batch_normalization_3

    hls::stream<layer21_t> layer30_cpy1("layer30_cpy1");
    #pragma HLS STREAM variable=layer30_cpy1 depth=64
    hls::stream<layer21_t> layer30_cpy2("layer30_cpy2");
    #pragma HLS STREAM variable=layer30_cpy2 depth=64
    hls::stream<layer21_t> layer30_cpy3("layer30_cpy3");
    #pragma HLS STREAM variable=layer30_cpy3 depth=64
    nnet::clone_stream<layer21_t, layer21_t, 1024>(layer21_out, layer30_cpy1, layer30_cpy2, layer30_cpy3); // clone_batch_normalization_3

    hls::stream<layer37_t> layer37_out("layer37_out");
    #pragma HLS STREAM variable=layer37_out depth=100
    nnet::zeropad2d_cl<layer21_t, layer37_t, config37>(layer30_cpy3, layer37_out); // zp2d_x_cls

    hls::stream<layer36_t> layer36_out("layer36_out");
    #pragma HLS STREAM variable=layer36_out depth=100
    nnet::zeropad2d_cl<layer21_t, layer36_t, config36>(layer30_cpy2, layer36_out); // zp2d_x_boxes

    hls::stream<layer35_t> layer35_out("layer35_out");
    #pragma HLS STREAM variable=layer35_out depth=100
    nnet::zeropad2d_cl<layer21_t, layer35_t, config35>(layer30_cpy1, layer35_out); // zp2d_x_prob

    hls::stream<layer22_t> layer22_out("layer22_out");
    #pragma HLS STREAM variable=layer22_out depth=64
    nnet::conv_2d_cl<layer35_t, layer22_t, config22>(layer35_out, layer22_out, w22, b22); // x_prob

    hls::stream<layer23_t> layer23_out("layer23_out");
    #pragma HLS STREAM variable=layer23_out depth=64
    nnet::sigmoid<layer22_t, layer23_t, sigmoid_config23>(layer22_out, layer23_out); // x_prob_sigmoid

    hls::stream<layer24_t> layer24_out("layer24_out");
    #pragma HLS STREAM variable=layer24_out depth=64
    nnet::conv_2d_cl<layer36_t, layer24_t, config24>(layer36_out, layer24_out, w24, b24); // x_boxes

    hls::stream<layer26_t> layer26_out("layer26_out");
    #pragma HLS STREAM variable=layer26_out depth=64
    nnet::concatenate3d<layer23_t, layer24_t, layer26_t, config26>(layer23_out, layer24_out, layer26_out); // concatenate

    hls::stream<layer27_t> layer27_out("layer27_out");
    #pragma HLS STREAM variable=layer27_out depth=64
    nnet::conv_2d_cl<layer37_t, layer27_t, config27>(layer37_out, layer27_out, w27, b27); // x_cls

    hls::stream<layer28_t> layer28_out("layer28_out");
    #pragma HLS STREAM variable=layer28_out depth=64
    nnet::sigmoid<layer27_t, layer28_t, sigmoid_config28>(layer27_out, layer28_out); // x_cls_sigmoid

    nnet::concatenate3d<layer26_t, layer28_t, result_t, config29>(layer26_out, layer28_out, layer29_out); // concatenate_1

}
