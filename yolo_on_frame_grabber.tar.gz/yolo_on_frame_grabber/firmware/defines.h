#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <cstddef>
#include <cstdio>

// hls-fpga-machine-learning insert numbers
#define N_INPUT_1_1 128
#define N_INPUT_2_1 128
#define N_INPUT_3_1 1
#define OUT_HEIGHT_31 130
#define OUT_WIDTH_31 130
#define N_CHAN_31 1
#define OUT_HEIGHT_2 128
#define OUT_WIDTH_2 128
#define N_FILT_2 16
#define OUT_HEIGHT_2 128
#define OUT_WIDTH_2 128
#define N_FILT_2 16
#define OUT_HEIGHT_5 64
#define OUT_WIDTH_5 64
#define N_FILT_5 16
#define OUT_HEIGHT_5 64
#define OUT_WIDTH_5 64
#define N_FILT_5 16
#define OUT_HEIGHT_32 66
#define OUT_WIDTH_32 66
#define N_CHAN_32 16
#define OUT_HEIGHT_7 64
#define OUT_WIDTH_7 64
#define N_FILT_7 16
#define OUT_HEIGHT_7 64
#define OUT_WIDTH_7 64
#define N_FILT_7 16
#define OUT_HEIGHT_10 32
#define OUT_WIDTH_10 32
#define N_FILT_10 16
#define OUT_HEIGHT_10 32
#define OUT_WIDTH_10 32
#define N_FILT_10 16
#define OUT_HEIGHT_33 34
#define OUT_WIDTH_33 34
#define N_CHAN_33 16
#define OUT_HEIGHT_12 32
#define OUT_WIDTH_12 32
#define N_FILT_12 16
#define OUT_HEIGHT_12 32
#define OUT_WIDTH_12 32
#define N_FILT_12 16
#define OUT_HEIGHT_15 16
#define OUT_WIDTH_15 16
#define N_FILT_15 16
#define OUT_HEIGHT_15 16
#define OUT_WIDTH_15 16
#define N_FILT_15 16
#define OUT_HEIGHT_34 18
#define OUT_WIDTH_34 18
#define N_CHAN_34 16
#define OUT_HEIGHT_17 16
#define OUT_WIDTH_17 16
#define N_FILT_17 16
#define OUT_HEIGHT_17 16
#define OUT_WIDTH_17 16
#define N_FILT_17 16
#define OUT_HEIGHT_20 8
#define OUT_WIDTH_20 8
#define N_FILT_20 16
#define OUT_HEIGHT_20 8
#define OUT_WIDTH_20 8
#define N_FILT_20 16
#define OUT_HEIGHT_20 8
#define OUT_WIDTH_20 8
#define N_FILT_20 16
#define OUT_HEIGHT_37 10
#define OUT_WIDTH_37 10
#define N_CHAN_37 16
#define OUT_HEIGHT_36 10
#define OUT_WIDTH_36 10
#define N_CHAN_36 16
#define OUT_HEIGHT_35 10
#define OUT_WIDTH_35 10
#define N_CHAN_35 16
#define OUT_HEIGHT_22 8
#define OUT_WIDTH_22 8
#define N_FILT_22 1
#define OUT_HEIGHT_22 8
#define OUT_WIDTH_22 8
#define N_FILT_22 1
#define OUT_HEIGHT_24 8
#define OUT_WIDTH_24 8
#define N_FILT_24 4
#define OUT_CONCAT_0_26 8
#define OUT_CONCAT_1_26 8
#define OUT_CONCAT_2_26 5
#define OUT_HEIGHT_27 8
#define OUT_WIDTH_27 8
#define N_FILT_27 10
#define OUT_HEIGHT_27 8
#define OUT_WIDTH_27 8
#define N_FILT_27 10
#define OUT_CONCAT_0_29 8
#define OUT_CONCAT_1_29 8
#define OUT_CONCAT_2_29 15

// hls-fpga-machine-learning insert layer-precision
typedef nnet::array<ap_fixed<16,8>, 1*1> input_t;
typedef nnet::array<ap_fixed<16,8>, 1*1> layer31_t;
typedef ap_fixed<16,8> model_default_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer2_t;
typedef ap_fixed<15,4> weight2_t;
typedef ap_fixed<7,1> bias2_t;
typedef nnet::array<ap_ufixed<16,8,AP_RND_CONV,AP_SAT>, 16*1> layer4_t;
typedef ap_fixed<18,8> q_activation_table_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer5_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer6_t;
typedef ap_fixed<16,8> batch_normalization_scale_t;
typedef ap_fixed<16,8> batch_normalization_bias_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer32_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer7_t;
typedef ap_fixed<16,3> weight7_t;
typedef ap_fixed<7,3> bias7_t;
typedef nnet::array<ap_ufixed<16,8,AP_RND_CONV,AP_SAT>, 16*1> layer9_t;
typedef ap_fixed<18,8> q_activation_1_table_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer10_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer11_t;
typedef ap_fixed<16,8> batch_normalization_1_scale_t;
typedef ap_fixed<16,8> batch_normalization_1_bias_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer33_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer12_t;
typedef ap_fixed<16,4> weight12_t;
typedef ap_fixed<8,3> bias12_t;
typedef nnet::array<ap_ufixed<16,8,AP_RND_CONV,AP_SAT>, 16*1> layer14_t;
typedef ap_fixed<18,8> q_activation_2_table_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer15_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer16_t;
typedef ap_fixed<16,8> batch_normalization_2_scale_t;
typedef ap_fixed<16,8> batch_normalization_2_bias_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer34_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer17_t;
typedef ap_fixed<16,3> weight17_t;
typedef ap_fixed<10,3> bias17_t;
typedef nnet::array<ap_ufixed<16,8,AP_RND_CONV,AP_SAT>, 16*1> layer19_t;
typedef ap_fixed<18,8> q_activation_3_table_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer20_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer21_t;
typedef ap_fixed<16,8> batch_normalization_3_scale_t;
typedef ap_fixed<16,8> batch_normalization_3_bias_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer37_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer36_t;
typedef nnet::array<ap_fixed<16,8>, 16*1> layer35_t;
typedef nnet::array<ap_fixed<16,8>, 1*1> layer22_t;
typedef ap_fixed<11,3> weight22_t;
typedef ap_fixed<2,2> bias22_t;
typedef nnet::array<ap_fixed<16,8>, 1*1> layer23_t;
typedef ap_fixed<18,8> x_prob_sigmoid_table_t;
typedef nnet::array<ap_fixed<16,8>, 4*1> layer24_t;
typedef ap_fixed<17,4> weight24_t;
typedef ap_fixed<4,4> bias24_t;
typedef nnet::array<ap_fixed<16,8>, 5*1> layer26_t;
typedef nnet::array<ap_fixed<16,8>, 10*1> layer27_t;
typedef ap_fixed<20,3> weight27_t;
typedef ap_fixed<8,2> bias27_t;
typedef nnet::array<ap_fixed<16,8>, 10*1> layer28_t;
typedef ap_fixed<18,8> x_cls_sigmoid_table_t;
typedef nnet::array<ap_fixed<16,8>, 15*1> result_t;

#endif
