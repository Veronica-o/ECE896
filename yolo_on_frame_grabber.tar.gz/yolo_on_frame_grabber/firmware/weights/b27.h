//Numpy array shape [10]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 10

#ifndef B27_H_
#define B27_H_

#ifndef __SYNTHESIS__
bias27_t b27[10];
#else
bias27_t b27[10] = {0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000};
#endif

#endif
