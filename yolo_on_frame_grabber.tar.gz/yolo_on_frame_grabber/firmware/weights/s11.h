//Numpy array shape [16]
//Min 0.999500393867
//Max 0.999500393867
//Number of zeros 0

#ifndef S11_H_
#define S11_H_

#ifndef __SYNTHESIS__
batch_normalization_1_scale_t s11[16];
#else
batch_normalization_1_scale_t s11[16] = {0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039};
#endif

#endif
