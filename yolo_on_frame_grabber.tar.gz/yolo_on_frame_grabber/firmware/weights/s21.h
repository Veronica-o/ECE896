//Numpy array shape [16]
//Min 0.999500393867
//Max 0.999500393867
//Number of zeros 0

#ifndef S21_H_
#define S21_H_

#ifndef __SYNTHESIS__
batch_normalization_3_scale_t s21[16];
#else
batch_normalization_3_scale_t s21[16] = {0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039};
#endif

#endif
