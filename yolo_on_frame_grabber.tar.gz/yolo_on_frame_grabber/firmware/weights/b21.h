//Numpy array shape [16]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 16

#ifndef B21_H_
#define B21_H_

#ifndef __SYNTHESIS__
batch_normalization_3_bias_t b21[16];
#else
batch_normalization_3_bias_t b21[16] = {0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000};
#endif

#endif
