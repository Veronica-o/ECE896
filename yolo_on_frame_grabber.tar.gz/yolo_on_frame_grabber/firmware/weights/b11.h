//Numpy array shape [16]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 16

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
batch_normalization_1_bias_t b11[16];
#else
batch_normalization_1_bias_t b11[16] = {0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000, 0.00000000};
#endif

#endif
