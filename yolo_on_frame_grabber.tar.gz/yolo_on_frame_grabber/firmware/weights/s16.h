//Numpy array shape [16]
//Min 0.999500393867
//Max 0.999500393867
//Number of zeros 0

#ifndef S16_H_
#define S16_H_

#ifndef __SYNTHESIS__
batch_normalization_2_scale_t s16[16];
#else
batch_normalization_2_scale_t s16[16] = {0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039, 0.99950039};
#endif

#endif
