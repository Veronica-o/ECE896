//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
bias24_t b24[4];
#else
bias24_t b24[4] = {0, 0, 0, 0};
#endif

#endif
