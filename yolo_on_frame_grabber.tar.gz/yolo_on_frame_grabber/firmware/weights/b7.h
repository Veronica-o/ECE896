//Numpy array shape [16]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 16

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
bias7_t b7[16];
#else
bias7_t b7[16] = {0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000};
#endif

#endif
