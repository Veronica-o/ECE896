//Numpy array shape [16]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 16

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
bias12_t b12[16];
#else
bias12_t b12[16] = {0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000, 0.00000};
#endif

#endif
